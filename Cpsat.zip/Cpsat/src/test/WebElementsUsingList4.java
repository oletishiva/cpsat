package test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class WebElementsUsingList4 {
	WebDriver driver;
  @Test
  public void setUp() {
	  
	  WebElement boxElement=driver.findElement(By.xpath("//*[@id='featured']/ul"));
	  List<WebElement> novels=boxElement.findElements(By.tagName("li"));
	  int count=novels.size();
	  System.out.println("novel Size:"+count);
	  for(int i=1;i<=count;i++)
		  System.out.println(driver.findElement(By.xpath("//*[@id='featured']/ul/li["+i+"]/div/a/span[2]")).getText());
	  
	  
  }
  @BeforeClass
  public void beforeClass() throws InterruptedException {
	  
	  System.setProperty("webdriver.chrome.driver","drivers/chromedriver1.exe");
		driver=new ChromeDriver();
		driver.get("https://letterboxd.com/");
		Thread.sleep(15000);
  }

  @AfterClass
  public void afterClass() {
  }

}
