package test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CrossWordExampleUsingScrollTestNG {

	WebDriver driver;
	@BeforeMethod
	public void setUp() throws Exception {
		
		System.setProperty("webdriver.chrome.driver","drivers/chromedriver1.exe");
		driver=new ChromeDriver();
		driver.get("https://crossword.in/");
	}

	@Test
	public void test() throws InterruptedException {
		JavascriptExecutor js=(JavascriptExecutor)driver;
		driver.findElement(By.id("search-input")).click();
		driver.findElement(By.id("search-input")).sendKeys("cricket");
		driver.findElement(By.xpath("//*[@class='search-go']")).click();
		String resultsText=driver.findElement(By.cssSelector("#search-results > div.search-summary.clearfix > div.summary-message > span.bn-message")).getText();
		int resultCount= Integer.parseInt(resultsText.replaceAll("[^0-9]", ""));
	//	String resultsText=driver.findElement(By.xpath("//*[@class='bn-message']")).getText();
		System.out.println("resultCount:"+resultCount);
		Thread.sleep(6000);
		driver.findElement(By.xpath("//*[@data-value='price_in_asc']")).click();
	
		Thread.sleep(30000);
		List<WebElement> myElements = driver.findElements(By.xpath("//*[@class='variant-final-price']"));
		
		while(myElements.size()<resultCount)
		{
			js.executeScript("window.scrollBy(0,200)", "");
			myElements = driver.findElements(By.xpath("//*[@class='variant-final-price']"));
		}
		System.out.println("myElements.size():"+myElements.size());
		if(myElements.size()==resultCount)
		{
			for(int i=1;i<resultCount-1;i++)
			{
				int first=Integer.parseInt(myElements.get(i).getText().replaceAll("[^0-9]", ""));
				int second=Integer.parseInt(myElements.get(i+1).getText().replaceAll("[^0-9]", ""));
				if(first<=second)
					System.out.println(first+"<="+second +":true");
				else
					System.err.println(first+"<="+second +":false" +"index:"+i);
					
			}
				
				
			
		}
		
	}
	
	
	@AfterMethod
	public void tearDown()
	{
		
	}

}

