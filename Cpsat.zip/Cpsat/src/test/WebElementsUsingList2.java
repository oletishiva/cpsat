package test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class WebElementsUsingList2 {
	WebDriver driver;
  @Test
  public void setUp() {
	  
	  WebElement boxElement=driver.findElement(By.xpath("//*[@id='recent-posts-5']/ul"));
	  List<WebElement> novels=boxElement.findElements(By.tagName("li"));
	  int count=novels.size();
	  System.err.println(count);
	  for(int i=0;i<count;i++)
	 System.out.println( novels.get(i).findElement(By.tagName("a")).getText());
	  
	  
  }
  @BeforeClass
  public void beforeClass() throws InterruptedException {
	  
	  System.setProperty("webdriver.chrome.driver","drivers/chromedriver1.exe");
		driver=new ChromeDriver();
		driver.get("https://testwithnishi.com/");
		Thread.sleep(15000);
  }

  @AfterClass
  public void afterClass() {
  }

}
