package test;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

public class CommonMethods {
	
	public static Object[][] getTableArray(String xlFilePath, String sheetName, String tableName) throws Exception{
	    Object[][] tabArray=null;
	    try{
	        Workbook workbook = Workbook.getWorkbook(new File(xlFilePath));
	        Sheet sheet = workbook.getSheet(sheetName); 
	        
	        int startRow,startCol, endRow, endCol,ci,cj;
	        
	        Cell tableStart=sheet.findCell(tableName);
	        //System.out.println(tableName);
	        startRow=tableStart.getRow();
	        startCol=tableStart.getColumn();
	        Cell tableEnd= sheet.findCell(tableName, startCol+1,startRow+1, 100, 64000,  false);                

	        endRow=tableEnd.getRow();
	        endCol=tableEnd.getColumn();
	        
	        System.out.println("startRow="+startRow+", endRow="+endRow+", " +
	                "startCol="+startCol+", endCol="+endCol);
	        tabArray=new String[endRow-startRow-1][endCol-startCol-1];
	        ci=0;

	        for (int i=startRow+1;i<endRow;i++,ci++){
	            cj=0;
	            for (int j=startCol+1;j<endCol;j++,cj++){
	                tabArray[ci][cj]=sheet.getCell(j,i).getContents();
	            }
	        }
	        	return(tabArray);
	}	catch(Exception e){
		System.out.println("Error in get Table Array"+ e);
		}
		return tabArray;
	}
	
	

}
