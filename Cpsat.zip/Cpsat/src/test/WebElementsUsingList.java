package test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class WebElementsUsingList {
	WebDriver driver;
  @Test
  public void setUp() {
	  
	  WebElement boxElement=driver.findElement(By.xpath("//*[@id='mw-content-text']/div/div[3]/ul"));
	  List<WebElement> novels=boxElement.findElements(By.tagName("a"));
	  for(WebElement ele:novels)
	  {
		  System.out.println(ele.getText());
		  
	  }
	  System.out.println("No of Novels:"+novels.size()); 
  }
  @BeforeClass
  public void beforeClass() throws InterruptedException {
	  
	  System.setProperty("webdriver.chrome.driver","drivers/chromedriver1.exe");
		driver=new ChromeDriver();
		driver.get("https://en.wikipedia.org/wiki/John_Grisham");
		Thread.sleep(15000);
  }

  @AfterClass
  public void afterClass() {
  }

}
