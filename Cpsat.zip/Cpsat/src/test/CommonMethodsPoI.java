package test;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class CommonMethodsPoI {
	
	//POI Method to get Excel Data 
			public static String[][] getExcelData(String fileName, String sheetName) {
				String[][] arrayExcelData = null;
				Workbook wb = null;
				try {
					File file = new File(fileName);
					FileInputStream fs = new FileInputStream(file);
					if(fileName.substring(fileName.indexOf(".")).equals(".xlsx")){
						//if file is xlsx type 
						wb =new XSSFWorkbook(fs);
					} 
					else if(fileName.substring(fileName.indexOf(".")).equals(".xls")){
						//if file is xls type
						wb = new HSSFWorkbook(fs);
					}
					
					Sheet sh = wb.getSheet(sheetName);

					int totalNoOfRows = sh.getPhysicalNumberOfRows();
					int totalNoOfCols = sh.getRow(0).getPhysicalNumberOfCells();
					
					System.out.println("Total Rows ->"+totalNoOfRows+"---*---Total Columns-->"+totalNoOfCols);
					
					arrayExcelData = new String[totalNoOfRows-1][totalNoOfCols];
					
					for (int i= 1 ; i < totalNoOfRows; i++) {

						for (int j=0; j < totalNoOfCols; j++) {
							arrayExcelData[i-1][j] = sh.getRow(i).getCell(j).getStringCellValue().toString();
						}

					}
				} catch (Exception e) {
					System.out.println("Error in Excel Data - > "+e);
				} 
				return arrayExcelData;
			}

}
