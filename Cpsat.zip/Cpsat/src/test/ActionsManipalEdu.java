package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionsManipalEdu {

	WebDriver driver;
	@Before
	public void setUp() throws Exception {
		
		System.setProperty("webdriver.chrome.driver","drivers/chromedriver1.exe");
		driver=new ChromeDriver();
		driver.get("https://manipal.edu/");
	}

	@After
	public void tearDown() throws Exception {
		
		
		Actions act=new Actions(driver);
		WebElement hoverAcadims=driver.findElement(By.xpath(".//*[@id='primary-sticky']/div/ul/li[2]/a"));
		act.moveToElement(hoverAcadims).build().perform();
		Thread.sleep(2000);
		WebElement hoverInstitutionList=driver.findElement(By.xpath("//*[@id='fat-menu']/div/ul/li[3]/a"));
		act.moveToElement(hoverInstitutionList).build().perform();
		Thread.sleep(2000);
		WebElement moveToHospitality =driver.findElement(By.partialLinkText("Hospitality"));
		act.moveToElement(moveToHospitality).build().perform();
		
		WebElement hoverArchitecture=driver.findElement(By.partialLinkText("Architecture"));
		act.moveToElement(hoverArchitecture).build().perform(); 
		
		driver.findElement(By.partialLinkText("Programs")).click();
		
		String programsCount=driver.findElement(By.cssSelector("div.stream-based-list-view1-header h6")).getText();
		
		
		assertTrue(programsCount.contains("7 PROGRAMS"));
		
		
		
		
	}

	@Test
	public void test() {
		
	}

}
