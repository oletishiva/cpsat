package test;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;

public class Imdb_DataProvider {
	
	WebDriver driver;
	
	@BeforeClass
	  public void setUp() {
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//drivers//chromedriver1.exe");
		driver=new ChromeDriver();
		
		/*System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"//drivers//geckodriver.exe");
		driver=new FirefoxDriver();*/
		driver.get("http://www.imdb.com/");
	  }	
  @Test(dataProvider = "movieData")
  public void test1(String movieTitle, String direactorName,String ActorName) {
	  
	  driver.findElement(By.xpath("//*[@id='navbar-query']")).click();
	  driver.findElement(By.xpath("//*[@id='navbar-query']")).sendKeys(movieTitle);
	  driver.findElement(By.xpath("//*[@id='navbar-submit-button']")).click();
	  if(isElementPresent(By.linkText(movieTitle)))
		  driver.findElement(By.partialLinkText(movieTitle)).click();
  }

  @DataProvider(name="movieData")
  public Object[][] movieList() throws Exception
  {
	 // new CommonMethods();
	Object[][] objRetArr=CommonMethods.getTableArray("data/movie_data.xls", "MovieList", "iMDBTestData");
		return 	  objRetArr;
  }
  
  
 
  
  public Boolean isElementPresent(By by)
  {
	 
	  try
	  {
		  driver.findElement(by);
		  return true;
	  }
	  catch(Exception e)
	  {
		  return false;
	  }
		  
  }
  
   

  @AfterClass
  public void afterClass() {
  }
  
  

}
