package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Basic_wiki {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","drivers/chromedriver1.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.wikipedia.org/");
		driver.findElement(By.xpath(".//*[@id='js-link-box-en']/strong")).click();
		driver.findElement(By.id("searchInput")).click();
		Thread.sleep(5000);
		driver.findElement(By.name("search")).sendKeys("Selenium");
	//	driver.findElement(By.id("searchInput")).sendKeys("Selenium");
		String title = driver.getTitle();
		if( title.equals("Selenium -Wikipedia"))
			System.out.println("Title is Correct-Pass");
			
			else
				System.out.println("Title is Correct-fail");               
			
		
		
		
		
		
		
		
	}

}

