package test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class WebElementsUsingList3 {
	WebDriver driver;
  @Test
  public void setUp() {
	  
	  int i=1;
	  int j=0;
	  while(isElementPresent(By.xpath("//*[@id='featured']/ul/li["+i+"]/div/a/span[2]")))
	  {
		i=i+1;
		j=j+1;
	  }
	  
	  System.err.println("no of pins:"+j);
  }
  @BeforeClass
  public void beforeClass() throws InterruptedException {
	  
	  System.setProperty("webdriver.chrome.driver","drivers/chromedriver1.exe");
		driver=new ChromeDriver();
		driver.get("https://letterboxd.com/");
		Thread.sleep(15000);
  }

  @AfterClass
  public void afterClass() {
  }

  public boolean isElementPresent(By by)
  {
	 try
	 {
		 driver.findElement(by);
		 return true;
	 }
	  catch(Exception e)
	 {
		  return false;
	 }
	  
  }
}
