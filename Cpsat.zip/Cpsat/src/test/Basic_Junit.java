package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Assert;

public class Basic_Junit {
	
	WebDriver driver;
	@Before
	public void setUp() throws Exception {
		
		System.setProperty("webdriver.chrome.driver","drivers/chromedriver1.exe");
		driver=new ChromeDriver();
		driver.get("https://www.wikipedia.org/");
	}

	@Test
	public void test() throws InterruptedException {
		driver.findElement(By.xpath(".//*[@id='js-link-box-en']/strong")).click();
		driver.findElement(By.id("searchInput")).click();
		Thread.sleep(5000);
		driver.findElement(By.name("search")).sendKeys("Selenium");
		Assert.assertEquals("", "");
		fail("Not yet implemented");
	}

	@After
	public void tearDown()
	{
		
	}
}
