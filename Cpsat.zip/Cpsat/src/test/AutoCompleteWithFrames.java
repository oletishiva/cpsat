package test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class AutoCompleteWithFrames {
	WebDriver driver;
	 @BeforeClass
	  public void beforeClass() throws InterruptedException {
		 System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//drivers//chromedriver1.exe");
		 driver=new ChromeDriver();
		 driver.get("http://jqueryui.com/autocomplete/");
		 Thread.sleep(2000);
	  }
	
  @Test
  public void autoCompleteTest() throws InterruptedException {
	  By demoFrame=By.className("demo-frame");
	  WebElement frame=driver.findElement(demoFrame);
	  driver.switchTo().frame(frame);
	  driver.findElement(By.id("tags")).click();
	  driver.findElement(By.id("tags")).sendKeys("ja");
	  Thread.sleep(2000);
	  By autoSuggestionBox=By.xpath("//*[@id='ui-id-1']");
	  WebElement autoSugBox=driver.findElement(autoSuggestionBox);
	  List<WebElement> suggestions=autoSugBox.findElements(By.tagName("li"));
	  System.err.println("no of suggestions:"+suggestions.size());	 
	  for(WebElement e:suggestions)
		 
		  {
		  System.out.println(e.getText());
		  if(e.getText().equalsIgnoreCase("Java"))
			  { 
			  e.click();
			  System.out.println("selected Java");
			  }
		  		
			  
		  }
	  driver.switchTo().defaultContent();
	  System.out.println(driver.findElement(By.cssSelector("h1.entry-title")).getText());
  }
  @AfterClass
  public void afterClass() {
  }

}
