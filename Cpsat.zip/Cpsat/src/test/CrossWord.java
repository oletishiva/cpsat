package test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CrossWord {

	WebDriver driver;
	@Before
	public void setUp() throws Exception {
		
		System.setProperty("webdriver.chrome.driver","drivers/chromedriver1.exe");
		driver=new ChromeDriver();
		driver.get("https://crossword.in/");
	}

	@Test
	public void test() throws InterruptedException {
		driver.findElement(By.id("search-input")).click();
		driver.findElement(By.id("search-input")).sendKeys("cricket");
		driver.findElement(By.xpath("//*[@class='search-go']")).click();
		
		String resultsText=driver.findElement(By.xpath("//*[@class='bn-message']")).getText();
		System.err.println(resultsText);
		Thread.sleep(6000);
		driver.findElement(By.xpath("//*[@data-value='price_in_asc']")).click();
	
		Thread.sleep(30000);
		List<WebElement> myElements = driver.findElements(By.xpath(".//*[@class='m-w'][1]"));
		for(WebElement e : myElements) {
		  System.out.println(e.getText());
	}
	}
	
	@After
	public void tearDown()
	{
		
	}

}

