package test;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;

public class NewTours_DataProvider {
	
	WebDriver driver;
	
	@BeforeClass
	  public void setUp() {
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//drivers//chromedriver1.exe");
		driver=new ChromeDriver();
		
		/*System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"//drivers//geckodriver.exe");
		driver=new FirefoxDriver();*/
		driver.get("http://newtours.demoaut.com/");
	  }	
  @Test(dataProvider = "creds")
  public void test1(String uname, String password) {
	  
	  driver.findElement(By.name("userName")).click();
	  driver.findElement(By.name("userName")).clear();
	  driver.findElement(By.name("userName")).sendKeys(uname);
	  driver.findElement(By.name("password")).click();
	  driver.findElement(By.name("password")).clear();
	  driver.findElement(By.name("password")).sendKeys(uname);
  }

  @DataProvider(name="creds")
  public String[][] loginCreds() {
   String cred[][]= CommonMethodsPoI.getExcelData("data//UserCreds.xlsx", "list");
   
   return cred;
   
  }
  

  @AfterClass
  public void afterClass() {
  }

}
