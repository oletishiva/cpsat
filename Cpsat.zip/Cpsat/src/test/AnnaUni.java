package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class AnnaUni {
	WebDriver driver;
	@Before
	public void setUp() throws Exception {
		
		System.setProperty("webdriver.chrome.driver","drivers/chromedriver1.exe");
		driver=new ChromeDriver();
		driver.get("https://annauniv.edu/");
	}

	@After
	public void tearDown() throws Exception {
		
	driver.findElement(By.linkText("Departments")).click();
	Actions act=new Actions(driver);
	WebElement civilEngg=driver.findElement(By.linkText("Faculty of Civil Engineering"));
	act.moveToElement(civilEngg).build().perform();
	WebElement submentuCivilEngin=driver.findElement(By.id("menuItemHilite28"));
	act.moveToElement(submentuCivilEngin).build().perform();
	driver.findElement(By.id("menuItemHilite28")).click();
	String title=driver.getTitle();
	if(title.equalsIgnoreCase(""))
		System.out.println();
	else
		System.out.println();
	}

	@Test
	public void test() {
		
	}

}
