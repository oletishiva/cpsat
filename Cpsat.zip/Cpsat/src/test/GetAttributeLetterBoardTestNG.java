package test;



import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.Assert.*;



public class GetAttributeLetterBoardTestNG {
	WebDriver driver;
	@BeforeClass
	public void setup() throws Exception
	{
		System.setProperty("webdriver.chrome.driver","drivers/chromedriver1.exe");
		driver=new ChromeDriver();
		driver.get("https://letterboxd.com/");
		Thread.sleep(15000);
	}
	@Test
	public void test() throws InterruptedException {
		driver.findElement(By.id("search-q")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("search-q")).sendKeys("Blade Runner 2049");
		Thread.sleep(5000);
		driver.findElement(By.cssSelector("input.action")).click();
		driver.findElement(By.partialLinkText("Blade Runner 2049")).click();
		Thread.sleep(10000);
		System.out.println(driver.findElement(By.xpath("//*[@id='tab-cast']/div/p/a[1]")).getAttribute("data-original-title"));
	}
 @AfterClass
	public void teardown()
	{
		
	}
}
