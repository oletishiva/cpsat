package test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;


public class Waits {
	
	WebDriver driver;
  @Test
  public void test1() throws IOException
  {
	  By element=By.xpath("//*[@id='infinite-handle']/span/button");
	  driver.findElement(By.cssSelector("input#searchboxinput")).click();
	  driver.findElement(By.cssSelector("input#searchboxinput")).sendKeys("HSR Layout");
	  driver.findElement(By.cssSelector("#searchbox-searchbutton")).click();
	  waitForElementTObePresent(By.xpath("//label[contains(@class,'section-hero-header-directions-label')]"));
	  takeScreenShot();
  }
  public void waitForPresenceOfAllElement(By by) {
	  WebDriverWait wait=new WebDriverWait(driver, 20);
	  wait.until(ExpectedConditions.presenceOfElementLocated(by));
			 

  }
  
 void waitForElementTObePresent(By by) {
	  WebDriverWait wait=new WebDriverWait(driver, 30);
	  wait.until(ExpectedConditions.elementToBeClickable(by));

  }
  @BeforeClass
  public void beforeClass() {
	  System.setProperty("webdriver.chrome.driver", "drivers/chromedriver1.exe");
	  driver=new ChromeDriver();
	  driver.get("https://www.google.com/maps/");
	  
  }

  @AfterClass
  public void afterClass() {
  }

  public void takeScreenShot() throws IOException
  {
 	 String str=driver.getTitle();
 	 File f= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
 	 FileUtils.copyFile(f, new File("/data/"+str+"_ScreenShot.jpg"));
 }
}
