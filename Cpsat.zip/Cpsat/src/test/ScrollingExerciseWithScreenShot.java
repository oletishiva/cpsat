package test;



import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import org.apache.commons.io.FileUtils;

import org.testng.Assert.*;



public class ScrollingExerciseWithScreenShot {
	WebDriver driver;
	@BeforeClass
	public void setup() throws Exception
	{
		System.setProperty("webdriver.chrome.driver","drivers/chromedriver1.exe");
		driver=new ChromeDriver();
		driver.get("https://testwithnishi.com/");
		
		driver.manage().window().maximize();
		
	}
	@Test
	public void scroll() throws InterruptedException, IOException {
		JavascriptExecutor js=(JavascriptExecutor)driver;
		WebElement elementToView=driver.findElement(By.xpath("//*[@id='infinite-handle']/span/button"));
		Thread.sleep(5000);
		js.executeScript("arguments[0].scrollIntoView(true);", elementToView);
		//js.executeScript("window.scrollTo(0,document.body.offsetHeight)");
		Thread.sleep(5000);
		takeScreenShot();
	}
 @AfterClass
	public void teardown()
	{
		
	 
	}
 
 public void takeScreenShot() throws IOException
 {
	 String str=driver.getTitle();
	 File f= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	 FileUtils.copyFile(f, new File("/data/"+str+"_ScreenShot.jpg"));
}
 
 


}