package test;



import static org.testng.Assert.assertTrue;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;





import org.testng.Assert.*;



public class ScrollingExercise {
	WebDriver driver;
	@BeforeClass
	public void setup() throws Exception
	{
		System.setProperty("webdriver.chrome.driver","drivers/chromedriver1.exe");
		driver=new ChromeDriver();
		driver.get("https://testwithnishi.com/");
		Thread.sleep(15000);
	}
	@Test
	public void scroll() throws InterruptedException {
		JavascriptExecutor js=(JavascriptExecutor)driver;
		//js.executeScript(arg0, arg1)
	}
 @AfterClass
	public void teardown()
	{
		
	}
}
