package test;



import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.Assert.*;



public class FirstWikiTestNG {
	WebDriver driver;
	@BeforeClass
	public void setup() throws Exception
	{
		System.setProperty("webdriver.chrome.driver","drivers/chromedriver1.exe");
		driver=new ChromeDriver();
		driver.get("https://www.wikipedia.org/");
	}
	@Test
	public void test() throws InterruptedException {
		driver.findElement(By.xpath(".//*[@id='js-link-box-en']/strong")).click();
		driver.findElement(By.id("searchInput")).click();
		Thread.sleep(5000);
		driver.findElement(By.name("search")).sendKeys("Selenium");
		System.err.println(driver.getTitle());
		Boolean result=driver.getTitle().contains("Wikipedia, the free encyclopedi");
		assertTrue(result);
	}
 @AfterClass
	public void teardown()
	{
		
	}
}
